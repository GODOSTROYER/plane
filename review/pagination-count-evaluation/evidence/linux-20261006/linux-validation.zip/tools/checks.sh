#!/bin/sh
set -eu
cd /code
python --version
python -m django --version
python -m ruff --version
python -m ruff check plane/utils/paginator.py plane/tests/unit/utils/test_paginator_evaluation.py plane/tests/contract/test_paginator_evaluation.py plane/tests/contract/api/test_work_item_pagination_evaluation.py
python -m ruff format --check plane/utils/paginator.py plane/tests/unit/utils/test_paginator_evaluation.py plane/tests/contract/test_paginator_evaluation.py plane/tests/contract/api/test_work_item_pagination_evaluation.py
python manage.py check
python manage.py makemigrations --check --dry-run
mkdir -p /tmp/workflow/apps
cp -a /code /tmp/workflow/apps/api
cd /tmp/workflow
python -m ruff check --fix apps/api
