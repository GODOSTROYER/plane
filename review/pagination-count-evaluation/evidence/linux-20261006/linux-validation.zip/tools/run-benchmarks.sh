#!/bin/sh
set -eu
python -m pip freeze > /verification-output/dependency-freeze.txt
export PLANE_RUN_PAGINATION_BENCHMARK=1
export PLANE_PAGINATION_BASELINE_FILE=/verification-output/paginator-baseline.py
export PLANE_BENCH_TRIALS=20
for rows in 100 1000 10000; do
  for body in 0 4096; do
    export PLANE_BENCH_ROWS="$rows"
    export PLANE_BENCH_BODY_BYTES="$body"
    export PLANE_BENCH_OUTPUT="/verification-output/benchmark-${rows}-${body}.json"
    echo "Benchmark: rows=$rows body=$body"
    pytest plane/tests/test_pagination_benchmark.py --nomigrations -o addopts= -q -s --junitxml="/verification-output/benchmark-${rows}-${body}.xml"
  done
done
