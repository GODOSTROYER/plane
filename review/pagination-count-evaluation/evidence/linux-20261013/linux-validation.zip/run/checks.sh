#!/bin/sh
set -eu
cd /code
python --version
python -m django --version
python -m ruff --version
python -m ruff check plane/utils/paginator.py plane/app/views/issue/base.py plane/tests/unit/utils/test_paginator_evaluation.py plane/tests/contract/test_paginator_evaluation.py plane/tests/contract/api/test_work_item_pagination_evaluation.py
python -m ruff format --check plane/utils/paginator.py plane/tests/unit/utils/test_paginator_evaluation.py plane/tests/contract/test_paginator_evaluation.py plane/tests/contract/api/test_work_item_pagination_evaluation.py
python -m ruff format --check --range 390-405 plane/app/views/issue/base.py
python manage.py check
python manage.py makemigrations --check --dry-run
python -m pip freeze > /verification-output/dependency-freeze.txt
