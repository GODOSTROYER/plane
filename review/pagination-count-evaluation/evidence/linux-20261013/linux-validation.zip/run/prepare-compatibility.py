from pathlib import Path
import argparse
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, default=Path.cwd())
parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent)
args = parser.parse_args()
repo = args.repo.resolve()
out = args.output.resolve()
source = (repo / 'apps/api/plane/utils/paginator.py').read_text()
changes = {
    '        # Duplicate the queryset so it does not evaluate on any python ops\n        page_results = queryset[offset:stop].values("id")\n': '',
    '        # Check if there are more results available after the current page\n': '        # Local compatibility check with upstream PR #9948.\n        has_next = total_count > offset + limit\n',
    'next_cursor = Cursor(limit, page + 1, False, page_results.count() > limit)': 'next_cursor = Cursor(limit, page + 1, False, has_next)',
}
for old, new in changes.items():
    assert source.count(old) == 1
    source = source.replace(old, new)
(out / 'combined-paginator.py').write_text(source, newline='\n')
original = (out / 'adjacent-test-paginator.py').read_bytes()
assert subprocess.check_output(['git', 'hash-object', '--stdin'], input=original, cwd=repo).decode().strip() == 'd36d302ccb209e3895201d04af6d581baad9b8f2'
(out / 'combined-test-paginator.py').write_bytes(original)
