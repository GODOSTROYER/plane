$ErrorActionPreference = 'Stop'
$evidenceRoot = 'Z:\OSS\reviews\plane-pagination-callback-review'
& 'C:\Program Files\Docker\Docker\resources\bin\docker.exe' compose -p plane-pagination-callback-review -f docker-compose-test.yml run --rm -v "${evidenceRoot}:/verification-output" -v "${evidenceRoot}\combined-paginator.py:/code/plane/utils/paginator.py:ro" -v "${evidenceRoot}\combined-test-paginator.py:/code/plane/tests/unit/utils/test_paginator.py:ro" api-tests /bin/sh -ec 'python -m pip freeze > /verification-output/test-dependency-freeze.txt; pytest plane/tests/unit/utils/test_paginator.py plane/tests/unit/utils/test_paginator_evaluation.py plane/tests/contract/test_paginator_evaluation.py plane/tests/contract/api/test_work_item_pagination_evaluation.py --nomigrations -o addopts= -q --junitxml=/verification-output/combined-focused.xml' *> "${evidenceRoot}\combined-focused.log"
$result = $LASTEXITCODE
Get-Content -LiteralPath "${evidenceRoot}\combined-focused.log" -Tail 14
exit $result
