# Plane project-list user expansion evidence

This is a local review bundle for conditional user/avatar batching in the project-list API. It contains the production patch, regression source, fixture/benchmark scripts, raw measurements, representative plans, and allowlisted validation logs. It does not publish the contribution or establish production performance.

- Base: `7466675e471efe1c96b122615f7a0d30c9b2eb05` in `makeplane/plane`.
- Unchanged production implementation: `9227478e0cdb08165ba55e8189872cdb9b99b5e6`.
- Packaged source snapshot: `c70e8050e728a9cd5cbb5549eb931b937c7e3e8c` — Committed snapshot.
- [Metadata and original/bundled file hashes](metadata.json).
- [Sanitization policy and replacement counts](SANITIZATION.json).
- [SHA256 manifest](SHA256SUMS).
- [Final statement accounting and query classification](evidence/QUERY_ACCOUNTING.md).

## Read the evidence

`raw/final/final-http-uninstrumented-*.json` contains the final request timing trials. SQL capture is disabled during these timing trials. `raw/final/final-sql-*.json` separately records parameter-free SQL and statement counts. Both sets must be present before this bundle can be created, and their production source hashes must match the packaged snapshot. Response equivalence assertions run in the benchmark harness. A separate socket test verifies real HTTP behavior; it is not the timed workload.

The timing scope is the complete Django stack through `APIClient`, including authentication, middleware, pagination and response handling, with no TCP transport. The local fixture workspaces have 100 projects for the final endpoint experiment. The uninstrumented files provide their individual repeated trials and summary statistics; do not combine them with the earlier instrumented samples.

`raw/historical-instrumented/` preserves the earlier final-implementation HTTP experiment that recorded SQL inside the timer. `raw/historical-exploratory/` preserves the initial four-strategy ORM and HTTP comparisons. `raw/historical-refined/` preserves the contender comparisons after refreshing PostgreSQL statistics. Those ORM comparisons cover pages up to 500, and their measured source stage differs from the final implementation. Source hashes and timing scopes remain in each file.

`plans/historical-refined/` contains representative PostgreSQL `EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)` plans from the refreshed-statistics comparison. They retain estimates, actual rows, loops, buffers, sort details, planning and execution time. They compare the original main query with the widened user/avatar join candidate. They are historical candidate plans, not plans of every final HTTP statement or measurements of full request latency.

`logs/final/` contains the strengthened-regression validation logs, including `strengthened-linux-docker-suite.log`: the complete output of the repository's Linux Docker Compose backend suite. It records 732 passed tests, including all 32 project-expansion regressions. The earlier `strengthened-docker.log` documents an initial startup failure and is superseded by the later passing Linux run. `logs/historical/` preserves logs from earlier stages. Use their collection counts, filenames and the current source snapshot when interpreting them. Missing optional logs are listed in `metadata.json`; their absence is not a pass. Historical full-cover ORM measurements do not turn the sparse-field cover HTTP/plan artifacts into full-cover endpoint evidence.

## Verify the bundle

From the extracted directory, using Python 3.12 or later:

```text
python tools/build_evidence_bundle.py --verify ../plane-evidence.zip
```

Replace `../plane-evidence.zip` with the archive's actual location. The verifier checks every member, rejects unlisted/duplicate/unsafe paths, and checks SHA256 and ZIP CRC values without extracting or executing the contents. Alternatively, run `sha256sum -c SHA256SUMS` in the extracted directory on a system with that utility. The manifest covers every bundle file except itself; the builder prints an additional checksum of the complete ZIP.

## Reproduce with a clean local Plane checkout

Use an isolated checkout of `makeplane/plane` at the base commit and disposable PostgreSQL/Redis services. Provision the repository's pinned API test dependencies and a compatible Python environment using its `apps/api/tests/RUNNING_TESTS.md` instructions. This bundle intentionally does not include a virtual environment, service binaries, `.env`, database dump, credentials or a full source tree.

The original local runs used Windows, Python 3.12.6, Django 5.2.17, PostgreSQL 15.19 and Redis 8.0.5, with the pinned `psycopg-binary` driver; the redundant `psycopg-c` package was omitted on Windows. The repository's Docker setup is an alternative environment, not a claim that these measurements were run in Docker. Inspect the measured JSON provenance for versions associated with each experiment. Timing differences on another machine are expected.

For the commands below, use sibling directories named `plane-repro` (the clean checkout) and `plane-query-optimization-evidence` (this extracted bundle). Run from their common parent. The commands use Git and Python and contain no original host paths:

```text
git -C plane-repro checkout --detach 7466675e471efe1c96b122615f7a0d30c9b2eb05
git -C plane-repro apply ../plane-query-optimization-evidence/patches/production.patch
python -c "from pathlib import Path; import shutil; p='apps/api/plane/tests/contract/api/test_project_list_expansion_queries.py'; shutil.copy2(Path('plane-query-optimization-evidence/source')/p, Path('plane-repro')/p)"
```

Configure `DATABASE_URL` and `REDIS_URL` in your shell for disposable local services, using your own local test credentials. Set `DJANGO_SETTINGS_MODULE=plane.settings.test`, use a fresh local `SECRET_KEY`, and disable read-replica routing for the default-database comparison. Follow the checkout's test setup for remaining environment values. Test processes must be able to create a PostgreSQL test database. Nothing should point to production infrastructure. Test fixtures create rows, and pytest rolls them back or flushes them as appropriate.

From `plane-repro/apps/api`, with the prepared environment activated:

```text
python -m pytest plane/tests/contract/api/test_project_list_expansion_queries.py --reuse-db --nomigrations -q -p no:cacheprovider -o addopts= --tb=short
python -m pytest plane/tests --reuse-db --nomigrations -q -p no:cacheprovider -o addopts= --tb=short
python -m pytest ../../../plane-query-optimization-evidence/tools/test_final_endpoint.py -c pytest.ini --reuse-db --nomigrations -q -s -p no:cacheprovider -o addopts= --tb=short
```

Run benchmarks without other test/benchmark workloads at the same time. The final harness seeds the distinct-user, shared-user, and null-user datasets, refreshes statistics, compares legacy expansion loading with the production implementation, checks response equality, captures SQL separately, and runs the TCP smoke test. New output files are written to the extracted bundle's top-level directory, leaving the packaged originals under `raw/` intact. Preserve those new files under a distinct run directory if repeating the experiment.

The broader historical strategy experiments can be rerun with the same command and configuration by substituting `test_benchmark_local.py` or `test_refined_benchmark.py`. They use the included `benchmark_project_expansion.py` and the same regression fixture helpers. Reruns on the final source have new provenance and are not bit-for-bit replays of the historical source stage. The standalone benchmark's CLI also supports an already seeded local workspace; read its `--help` and use `--confirm-local-test-data`.

To demonstrate that the regression tests detect the missing optimization, prepare a second clean checkout at the base commit, copy the same regression file, and run its focused pytest command **without applying the production patch**. Batching assertions are expected to fail there. Keep this distinct from successful final-source validation and do not run it concurrently with timing work.

## Source and sanitization

The production patch is generated only for `apps/api/plane/api/views/project.py`. The current regression module and all four benchmark/fixture scripts are copied byte-for-byte. Public synthetic fixture constants required by the upstream test fixtures remain in those sources. No runtime credentials are included.

Evidence JSON/log/XML files are normalized and sanitized. Absolute host paths and hostname attributes are removed; fixture UUIDs and email values are replaced consistently across artifacts. Sensitive JSON values, credential URLs and secret assignments are redacted. Numerical measurements, SQL structure and source/response hashes are retained. Original response hashes describe the measured responses before sanitization; bundle checksums describe the sanitized files. Pseudonymization preserves correlation but is not reversible encryption and does not reproduce the original fixture identities.

The builder uses explicit filename allowlists, rejects linked inputs escaping the evidence/source roots, validates final source hashes, detects inputs changed during capture, and refuses to overwrite an existing archive. It does not read `.env` files, runtime environment values, full baseline trees or database data. `tools/build_evidence_bundle.py` can rebuild from the original evidence layout using `--source`, `--evidence-root`, `--expected-source-commit` and `--output`; the extracted bundle is a review layout rather than a replacement for that original input tree.

## Inventory

- [LICENSE.txt](LICENSE.txt)
- [SANITIZATION.json](SANITIZATION.json)
- [evidence/QUERY_ACCOUNTING.md](evidence/QUERY_ACCOUNTING.md)
- [logs/final/strengthened-baseline.log](logs/final/strengthened-baseline.log)
- [logs/final/strengthened-checks.log](logs/final/strengthened-checks.log)
- [logs/final/strengthened-docker.log](logs/final/strengthened-docker.log)
- [logs/final/strengthened-final-endpoint.log](logs/final/strengthened-final-endpoint.log)
- [logs/final/strengthened-focused.log](logs/final/strengthened-focused.log)
- [logs/final/strengthened-full-suite.log](logs/final/strengthened-full-suite.log)
- [logs/final/strengthened-full-suite.xml](logs/final/strengthened-full-suite.xml)
- [logs/final/strengthened-linux-docker-suite.log](logs/final/strengthened-linux-docker-suite.log)
- [logs/historical/baseline-final-tests.log](logs/historical/baseline-final-tests.log)
- [logs/historical/benchmarks.log](logs/historical/benchmarks.log)
- [logs/historical/copyright.log](logs/historical/copyright.log)
- [logs/historical/django-check.log](logs/historical/django-check.log)
- [logs/historical/final-endpoint.log](logs/historical/final-endpoint.log)
- [logs/historical/focused-after.log](logs/historical/focused-after.log)
- [logs/historical/format-changed.log](logs/historical/format-changed.log)
- [logs/historical/full-suite.log](logs/historical/full-suite.log)
- [logs/historical/full-suite.xml](logs/historical/full-suite.xml)
- [logs/historical/migration-check.log](logs/historical/migration-check.log)
- [logs/historical/refined-benchmarks.log](logs/historical/refined-benchmarks.log)
- [logs/historical/ruff-changed.log](logs/historical/ruff-changed.log)
- [logs/historical/ruff-ci.log](logs/historical/ruff-ci.log)
- [metadata.json](metadata.json)
- [patches/production.patch](patches/production.patch)
- [plans/historical-refined/refined-explain-distinct.json](plans/historical-refined/refined-explain-distinct.json)
- [plans/historical-refined/refined-explain-null.json](plans/historical-refined/refined-explain-null.json)
- [plans/historical-refined/refined-explain-shared.json](plans/historical-refined/refined-explain-shared.json)
- [plans/historical-refined/refined-explain-url_only.json](plans/historical-refined/refined-explain-url_only.json)
- [raw/final/final-http-uninstrumented-distinct.json](raw/final/final-http-uninstrumented-distinct.json)
- [raw/final/final-http-uninstrumented-null.json](raw/final/final-http-uninstrumented-null.json)
- [raw/final/final-http-uninstrumented-shared.json](raw/final/final-http-uninstrumented-shared.json)
- [raw/final/final-sql-distinct.json](raw/final/final-sql-distinct.json)
- [raw/final/final-sql-null.json](raw/final/final-sql-null.json)
- [raw/final/final-sql-shared.json](raw/final/final-sql-shared.json)
- [raw/historical-exploratory/benchmark-covers.json](raw/historical-exploratory/benchmark-covers.json)
- [raw/historical-exploratory/benchmark-distinct.json](raw/historical-exploratory/benchmark-distinct.json)
- [raw/historical-exploratory/benchmark-null.json](raw/historical-exploratory/benchmark-null.json)
- [raw/historical-exploratory/benchmark-shared.json](raw/historical-exploratory/benchmark-shared.json)
- [raw/historical-exploratory/benchmark-url_only.json](raw/historical-exploratory/benchmark-url_only.json)
- [raw/historical-exploratory/http-stack-covers.json](raw/historical-exploratory/http-stack-covers.json)
- [raw/historical-exploratory/http-stack-distinct.json](raw/historical-exploratory/http-stack-distinct.json)
- [raw/historical-exploratory/http-stack-null.json](raw/historical-exploratory/http-stack-null.json)
- [raw/historical-exploratory/http-stack-shared.json](raw/historical-exploratory/http-stack-shared.json)
- [raw/historical-exploratory/http-stack-url_only.json](raw/historical-exploratory/http-stack-url_only.json)
- [raw/historical-instrumented/final-http-distinct.json](raw/historical-instrumented/final-http-distinct.json)
- [raw/historical-instrumented/final-http-null.json](raw/historical-instrumented/final-http-null.json)
- [raw/historical-instrumented/final-http-shared.json](raw/historical-instrumented/final-http-shared.json)
- [raw/historical-refined/refined-distinct.json](raw/historical-refined/refined-distinct.json)
- [raw/historical-refined/refined-null.json](raw/historical-refined/refined-null.json)
- [raw/historical-refined/refined-shared.json](raw/historical-refined/refined-shared.json)
- [raw/historical-refined/refined-url_only.json](raw/historical-refined/refined-url_only.json)
- [source/apps/api/plane/tests/contract/api/test_project_list_expansion_queries.py](source/apps/api/plane/tests/contract/api/test_project_list_expansion_queries.py)
- [tools/benchmark_project_expansion.py](tools/benchmark_project_expansion.py)
- [tools/build_evidence_bundle.py](tools/build_evidence_bundle.py)
- [tools/test_benchmark_local.py](tools/test_benchmark_local.py)
- [tools/test_final_endpoint.py](tools/test_final_endpoint.py)
- [tools/test_refined_benchmark.py](tools/test_refined_benchmark.py)
