#!/usr/bin/env python3
"""Build a local, allowlisted Plane review ZIP; no services or network access.

Run after final validation artifacts and the source commit are complete. The
default build requires all three uninstrumented timing and parameter-free SQL
artifacts. --check-only validates the prospective bundle without writing it.
--verify checks an existing ZIP without extracting or executing its contents.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import posixpath
import re
import subprocess
import sys
import uuid
import xml.etree.ElementTree as ET
import zipfile


BASE_COMMIT = "7466675e471efe1c96b122615f7a0d30c9b2eb05"
PRODUCTION_COMMIT = "9227478e0cdb08165ba55e8189872cdb9b99b5e6"
PRODUCTION_PATH = "apps/api/plane/api/views/project.py"
REGRESSION_PATH = "apps/api/plane/tests/contract/api/test_project_list_expansion_queries.py"
ARCHIVE_ROOT = "plane-query-optimization-evidence"
MAX_FILE_BYTES = 50 * 1024 * 1024
UUID_NAMESPACE = uuid.UUID("1e2d8d0e-14d4-51c7-b59a-a98d934371f9")

# Literal filename allowlists only: do not replace these with glob/rglob/walk.
FINAL_FILES = tuple(
    f"{prefix}-{distribution}.json"
    for prefix in ("final-http-uninstrumented", "final-sql")
    for distribution in ("distinct", "shared", "null")
)
TOOLS = (
    "test_final_endpoint.py",
    "test_benchmark_local.py",
    "test_refined_benchmark.py",
    "benchmark_project_expansion.py",
    "build_evidence_bundle.py",
    "evidence_bundle_README.template.md",
)
HISTORICAL_FILES = {
    "raw/historical-instrumented": tuple(
        f"final-http-{distribution}.json" for distribution in ("distinct", "shared", "null")
    ),
    "raw/historical-exploratory": tuple(
        f"{prefix}-{distribution}.json"
        for prefix in ("benchmark", "http-stack")
        for distribution in ("distinct", "shared", "url_only", "null", "covers")
    ),
    "raw/historical-refined": tuple(
        f"refined-{distribution}.json" for distribution in ("distinct", "shared", "url_only", "null")
    ),
    "plans/historical-refined": tuple(
        f"refined-explain-{distribution}.json"
        for distribution in ("distinct", "shared", "url_only", "null")
    ),
}
LOG_FILES = (
    "baseline-final-tests.log",
    "focused-after.log",
    "focused-final.log",
    "full-suite.log",
    "final-endpoint.log",
    "benchmarks.log",
    "refined-benchmarks.log",
    "ruff-changed.log",
    "format-changed.log",
    "ruff-ci.log",
    "copyright.log",
    "django-check.log",
    "migration-check.log",
)
FINAL_LOG_FILES = (
    "strengthened-focused.log",
    "strengthened-baseline.log",
    "strengthened-full-suite.log",
    "strengthened-final-endpoint.log",
    "strengthened-checks.log",
    "strengthened-docker.log",
    "strengthened-linux-docker-suite.log",
)
SENSITIVE_KEYS = {
    "password", "secret", "secret_key", "access_token", "refresh_token", "api_key",
    "api_token", "authorization", "cookie", "set-cookie", "database_url",
    "database_read_replica_url", "redis_url", "amqp_url", "aws_secret_access_key",
}
UUID_PATTERN = re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", re.I)
EMAIL_PATTERN = re.compile(r"(?<![\w.+-])[\w.+%-]+@[a-z0-9.-]+\.[a-z]{2,}\b", re.I)
WINDOWS_PATH_PATTERN = re.compile(r"(?<![\w\\])(?:\\\\\?\\)?[a-z]:[\\/][^\s<>\"'|]*", re.I)
UNIX_HOST_PATH_PATTERN = re.compile(
    r"(?<![\w:/])/(?:home|Users|private|tmp|var|mnt|workspace|workspaces|opt)/(?:[^\s<>\"'|]*)"
)
CREDENTIAL_URL_PATTERN = re.compile(
    r"\b(?:postgres(?:ql)?|rediss?|amqps?|https?)://[^\s/@\"']+:[^\s/@\"']+@[^\s\"'<>]+", re.I
)
SECRET_ASSIGNMENT_PATTERN = re.compile(
    r"(?im)(\b(?:SECRET_KEY|DATABASE_URL|DATABASE_READ_REPLICA_URL|REDIS_URL|AMQP_URL|"
    r"AWS_SECRET_ACCESS_KEY|GITHUB_ACCESS_TOKEN|ACCESS_TOKEN|REFRESH_TOKEN|PASSWORD)"
    r"[\"']?\s*[:=]\s*)(?:\"[^\"\r\n]*\"|'[^'\r\n]*'|[^\s,}\r\n]+)"
)
SECRET_SIGNATURE_PATTERN = re.compile(
    r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|"
    r"\bAKIA[0-9A-Z]{16}\b|\bgh[pousr]_[A-Za-z0-9]{20,}\b|"
    r"\bgithub_pat_[A-Za-z0-9_]{20,}\b|\bxox[baprs]-[A-Za-z0-9-]{20,}\b"
)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_bytes(value) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def git(source: Path, *args: str) -> bytes:
    result = subprocess.run(
        ["git", "-C", str(source), *args], check=False, capture_output=True,
    )
    if result.returncode:
        # Git's stderr may contain local paths: keep failure output portable.
        raise ValueError(f"git {' '.join(args)} failed (exit {result.returncode})")
    return result.stdout


def read_allowed(root: Path, relative: str) -> bytes:
    relative_path = PurePosixPath(relative)
    if relative_path.is_absolute() or ".." in relative_path.parts:
        raise ValueError(f"Unsafe allowlist path: {relative}")
    candidate = root.joinpath(*relative_path.parts)
    if not candidate.resolve().is_relative_to(root.resolve()):
        raise ValueError(f"Allowlisted file escapes its input root: {relative}")
    for part in (candidate, *candidate.parents):
        if part == root:
            break
        if part.is_symlink() or (hasattr(part, "is_junction") and part.is_junction()):
            raise ValueError(f"Links are not allowed in bundle inputs: {relative}")
    if candidate.stat().st_size > MAX_FILE_BYTES:
        raise ValueError(f"Allowlisted file exceeds size limit: {relative}")
    return candidate.read_bytes()


def decode(data: bytes) -> str:
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16")
    return data.decode("utf-8-sig")


class Sanitizer:
    """Pseudonymize fixture values consistently; never export the reverse map."""

    def __init__(self, evidence: Path, source: Path):
        self.counts: Counter[str] = Counter()
        self.paths = []
        for root, alias in (
            (evidence, "<EVIDENCE_ROOT>"),
            (source, "<SOURCE_ROOT>"),
            (source.parent / "plane-tools", "<RUNTIME_ROOT>"),
        ):
            forms = {str(root), root.as_posix(), str(root).replace("\\", "\\\\")}
            self.paths.extend((form, alias) for form in forms)
        self.paths.sort(key=lambda pair: len(pair[0]), reverse=True)

    def replace(self, pattern: re.Pattern, text: str, kind: str, replacement) -> str:
        text, count = pattern.subn(replacement, text)
        self.counts[kind] += count
        return text

    def text(self, text: str, *, fixture_values: bool = True) -> str:
        text = text.replace("\r\n", "\n")
        for path, alias in self.paths:
            text = self.replace(re.compile(re.escape(path), re.I), text, "known_host_path", lambda _: alias)
        text = self.replace(WINDOWS_PATH_PATTERN, text, "other_host_path", "<HOST_PATH>")
        text = self.replace(UNIX_HOST_PATH_PATTERN, text, "other_host_path", "<HOST_PATH>")
        text = self.replace(CREDENTIAL_URL_PATTERN, text, "credential_url", "<CREDENTIAL_URL_REMOVED>")
        text = self.replace(
            SECRET_ASSIGNMENT_PATTERN, text, "secret_assignment",
            lambda match: match.group(1) + '"<REDACTED>"',
        )
        if fixture_values:
            text = self.replace(
                EMAIL_PATTERN, text, "fixture_email",
                lambda match: "fixture-" + sha256(match.group(0).lower().encode())[:16] + "@example.invalid",
            )
            text = self.replace(
                UUID_PATTERN, text, "fixture_uuid",
                lambda match: str(uuid.uuid5(UUID_NAMESPACE, match.group(0).lower())),
            )
            text = text.replace("test-api-token-12345", "<SYNTHETIC_API_TOKEN>")
        return text

    def value(self, value):
        if isinstance(value, dict):
            result = {}
            for key, item in value.items():
                if key.lower() in SENSITIVE_KEYS:
                    result[key] = "<REDACTED>"
                    self.counts["sensitive_json_value"] += 1
                elif key.lower() in {"hostname", "computername"}:
                    result[key] = "sanitized-host"
                    self.counts["hostname"] += 1
                else:
                    result[self.text(key)] = self.value(item)
            return result
        if isinstance(value, list):
            return [self.value(item) for item in value]
        return self.text(value) if isinstance(value, str) else value

    def artifact(self, relative: str, data: bytes) -> bytes:
        text = decode(data)
        if relative.endswith(".json"):
            return json_bytes(self.value(json.loads(text)))
        if relative.endswith(".xml"):
            root = ET.fromstring(text)
            for element in root.iter():
                for key, value in list(element.attrib.items()):
                    if key.lower() == "hostname":
                        element.set(key, "sanitized-host")
                        self.counts["hostname"] += 1
                    else:
                        element.set(key, self.text(value))
                if element.text:
                    element.text = self.text(element.text)
                if element.tail:
                    element.tail = self.text(element.tail)
            return ET.tostring(root, encoding="utf-8", xml_declaration=True) + b"\n"
        return self.text(text).encode("utf-8")


def audit(relative: str, data: bytes, *, source: bool = False) -> None:
    text = decode(data)
    if "\x00" in text:
        raise ValueError(f"Unexpected binary content: {relative}")
    if SECRET_SIGNATURE_PATTERN.search(text) or CREDENTIAL_URL_PATTERN.search(text):
        raise ValueError(f"Potential credential found; review input locally: {relative}")
    # Source files are copied byte-for-byte. Fail rather than silently rewriting
    # executable code if somebody later adds a local path or environment value.
    if source and (WINDOWS_PATH_PATTERN.search(text) or UNIX_HOST_PATH_PATTERN.search(text)):
        raise ValueError(f"Source file is not portable; remove local path before bundling: {relative}")
    if not source and (WINDOWS_PATH_PATTERN.search(text) or UNIX_HOST_PATH_PATTERN.search(text)):
        raise ValueError(f"Unsanitized host path: {relative}")


def verify_archive(path: Path) -> dict:
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("ZIP contains duplicate names")
        prefix = ARCHIVE_ROOT + "/"
        if any(not name.startswith(prefix) or ".." in PurePosixPath(name).parts or "\\" in name for name in names):
            raise ValueError("ZIP contains unsafe or unexpected member paths")
        manifest_name = prefix + "SHA256SUMS"
        records = {}
        for line in archive.read(manifest_name).decode("ascii").splitlines():
            digest, relative = line.split("  ", 1)
            if relative in records or not re.fullmatch(r"[a-f0-9]{64}", digest):
                raise ValueError("Malformed SHA256SUMS")
            records[relative] = digest
        expected = {prefix + relative for relative in records} | {manifest_name}
        if set(names) != expected:
            raise ValueError("SHA256SUMS does not cover the exact ZIP contents")
        for relative, digest in records.items():
            if sha256(archive.read(prefix + relative)) != digest:
                raise ValueError(f"Checksum mismatch: {relative}")
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC check failed")
    return {"verified_files": len(records), "zip_sha256": sha256(path.read_bytes())}


def build(args) -> tuple[dict[str, bytes], dict]:
    evidence = args.evidence_root.resolve()
    source = args.source.resolve()
    head = git(source, "rev-parse", "HEAD").decode().strip()
    if args.expected_source_commit and not head.startswith(args.expected_source_commit):
        raise ValueError("Source HEAD does not match --expected-source-commit")
    base = git(source, "rev-parse", "--verify", args.base_commit + "^{commit}").decode().strip()
    production_commit = git(source, "rev-parse", "--verify", args.production_commit + "^{commit}").decode().strip()
    production = read_allowed(source, PRODUCTION_PATH)
    regression = read_allowed(source, REGRESSION_PATH)
    committed_production = git(source, "show", f"{production_commit}:{PRODUCTION_PATH}")
    # Git's LF checkout normalization is the only tolerated source difference.
    if production.replace(b"\r\n", b"\n") != committed_production.replace(b"\r\n", b"\n"):
        raise ValueError("Production source differs from the declared production commit")
    relevant_status = git(source, "status", "--porcelain=v1", "--untracked-files=no", "--", PRODUCTION_PATH, REGRESSION_PATH).decode().splitlines()
    if relevant_status and not args.allow_uncommitted_source:
        raise ValueError("Production/test source has uncommitted edits; commit it or explicitly use --allow-uncommitted-source")
    patch = git(source, "diff", "--no-ext-diff", "--no-textconv", "--binary", base, "--", PRODUCTION_PATH)
    if not patch:
        raise ValueError("Production patch is empty")

    entries: dict[str, bytes] = {}
    provenance = []
    missing = []
    sanitizer = Sanitizer(evidence, source)
    snapshots = [(source, PRODUCTION_PATH, production), (source, REGRESSION_PATH, regression)]

    def add(relative: str, data: bytes, origin: str, *, exact: bool = False):
        before = sanitizer.counts.copy()
        prepared = data
        if relative == "evidence/QUERY_ACCOUNTING.md":
            destinations = {
                record["input"].removeprefix("evidence/"): record["path"]
                for record in provenance if record["input"].startswith("evidence/")
            }
            destinations["QUERY_ACCOUNTING.md"] = relative

            def relocate_link(match):
                target = match.group(1).strip("<>").replace("\\", "/")
                path, separator, fragment = target.partition("#")
                prefix = evidence.as_posix().rstrip("/") + "/"
                if path.lower().startswith(prefix.lower()):
                    path = path[len(prefix):]
                destination = destinations.get(path.removeprefix("./"))
                if destination:
                    sanitizer.counts["portable_markdown_link"] += 1
                    rebased = posixpath.relpath(destination, str(PurePosixPath(relative).parent))
                    return "](" + rebased + (separator + fragment if separator else "") + ")"
                return match.group(0)

            prepared = re.sub(r"\]\(([^\n)]+)\)", relocate_link, decode(data)).encode("utf-8")
        output = prepared if exact else sanitizer.artifact(relative, prepared)
        audit(relative, output, source=exact)
        entries[relative] = output
        provenance.append({
            "path": relative, "input": origin, "input_sha256": sha256(data),
            "bundled_sha256": sha256(output), "byte_identical": data == output,
            "sanitization_counts": dict(sanitizer.counts - before),
        })

    def evidence_file(name: str, destination: str, *, required: bool = False, exact: bool = False):
        try:
            data = read_allowed(evidence, name)
        except FileNotFoundError:
            if required:
                raise ValueError(f"Required final artifact is missing: {name}") from None
            missing.append(name)
            return
        snapshots.append((evidence, name, data))
        add(destination, data, "evidence/" + name, exact=exact)

    add("patches/production.patch", patch, "git diff base -- production file", exact=True)
    add("source/" + REGRESSION_PATH, regression, "source/" + REGRESSION_PATH, exact=True)
    license_data = read_allowed(source, "LICENSE.txt")
    snapshots.append((source, "LICENSE.txt", license_data))
    add("LICENSE.txt", license_data, "source/LICENSE.txt", exact=True)
    for name in TOOLS:
        evidence_file("tools/" + name, "tools/" + name, required=True, exact=True)
    for name in FINAL_FILES:
        evidence_file(name, "raw/final/" + name, required=True)
        value = json.loads(decode(entries["raw/final/" + name]))
        recorded_sha = value.get("production_source_sha256")
        if recorded_sha and recorded_sha != sha256(production):
            raise ValueError(f"Final artifact source hash differs from source snapshot: {name}")
        if not recorded_sha:
            raise ValueError(f"Final artifact lacks production_source_sha256: {name}")
        if name.startswith("final-http-uninstrumented-"):
            if value.get("sql_capture_during_timing") is not False:
                raise ValueError(f"Final timing artifact does not declare SQL capture disabled: {name}")
        else:
            captures = value.get("captures", {})
            counts = value.get("query_counts", {})
            if set(captures) != {"legacy", "optimized"} or set(counts) != set(captures):
                raise ValueError(f"Incomplete final SQL variants: {name}")
            for variant, statements in captures.items():
                if len(statements) != counts[variant]:
                    raise ValueError(f"Final SQL statement count mismatch: {name}")
                if any(set(statement) != {"alias", "sql"} for statement in statements):
                    raise ValueError(f"Unexpected final SQL data (bound values must be omitted): {name}")
    for folder, names in HISTORICAL_FILES.items():
        for name in names:
            evidence_file(name, folder + "/" + name)
    for name in LOG_FILES:
        evidence_file("logs/" + name, "logs/historical/" + name)
    for name in FINAL_LOG_FILES:
        evidence_file("logs/" + name, "logs/final/" + name)
    evidence_file("full-suite.xml", "logs/historical/full-suite.xml")
    evidence_file("strengthened-full-suite.xml", "logs/final/strengthened-full-suite.xml")
    evidence_file("QUERY_ACCOUNTING.md", "evidence/QUERY_ACCOUNTING.md", required=True)

    metadata = {
        "schema_version": 1,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "publication": "local evidence only; no branch or artifact is published by this tool",
        "repository": "makeplane/plane",
        "base_commit": base,
        "production_commit": production_commit,
        "source_snapshot_commit": head,
        "relevant_source_status": relevant_status,
        "production_source_path": PRODUCTION_PATH,
        "production_source_sha256": sha256(production),
        "regression_source_path": "source/" + REGRESSION_PATH,
        "regression_source_sha256": sha256(regression),
        "production_patch_sha256": sha256(patch),
        "timing_scope": "Final APIClient Django stack timings, without SQL instrumentation; not TCP or production latency",
        "historical_scope": "Earlier instrumented HTTP timings and ORM strategy comparisons are historical and are stored separately",
        "plan_scope": "Representative refreshed PostgreSQL EXPLAIN ANALYZE plans from historical contender comparison; not final endpoint timings",
        "missing_optional_allowlisted_inputs": missing,
        "artifacts": provenance,
    }
    entries["metadata.json"] = json_bytes(metadata)
    entries["SANITIZATION.json"] = json_bytes({
        "policy": "Explicit file allowlist; no recursive source/runtime copying or environment reads",
        "excluded": [
            ".env files and environment dumps", "runtime credentials and service startup scripts",
            "verify.ps1 with host-specific runtime configuration", "database dumps/data directories",
            "baseline and ci-source trees", "baseline-api.tar", "downloaded kit and original host-path manifest",
            "unrelated PR/API responses", "host-specific review/draft documents",
        ],
        "source_policy": "Scripts, regression source and generated production patch are copied exactly; public synthetic fixture constants needed by upstream tests are retained",
        "artifact_policy": "JSON/log/XML host paths and hostname attributes are removed; fixture UUIDs/emails are deterministically pseudonymized; sensitive values and credential URLs are redacted",
        "uuid_method": "UUIDv5 in a fixed namespace; identical UUIDs correlate across artifacts; no original-to-replacement map is included",
        "email_method": "SHA256-derived fixture address at example.invalid; not reversible encryption",
        "quantitative_values": "Trial numbers, SQL structure, query counts, timings, plans, buffers, hashes and versions are retained",
        "integrity_note": "Source and response hashes in evidence describe the original measured bytes; SHA256SUMS describes the sanitized bundled bytes",
        "limitations": "Conservative patterns and allowlists reduce disclosure risk but are not a formal guarantee that arbitrary future input contains no secrets; review added allowlist entries",
        "replacement_counts": dict(sanitizer.counts),
    })
    template = decode(entries["tools/evidence_bundle_README.template.md"])
    inventory = "\n".join(f"- [{name}]({name})" for name in sorted(entries) if name != "tools/evidence_bundle_README.template.md")
    replacements = {
        "@@BASE_COMMIT@@": base,
        "@@PRODUCTION_COMMIT@@": production_commit,
        "@@SOURCE_COMMIT@@": head,
        "@@INVENTORY@@": inventory,
        "@@SOURCE_STATUS@@": "Committed snapshot" if not relevant_status else "Uncommitted source snapshot: see metadata.json",
    }
    for token, value in replacements.items():
        template = template.replace(token, value)
    if re.search(r"@@[A-Z_]+@@", template):
        raise ValueError("Unresolved README template token")
    entries["README.md"] = template.encode("utf-8")
    # Check local documentation links after rebasing; do not ship broken host
    # links or links to deliberately excluded local files.
    for document in ("README.md", "evidence/QUERY_ACCOUNTING.md"):
        for target in re.findall(r"\]\(([^\n)]+)\)", decode(entries[document])):
            target = target.strip("<>")
            if re.match(r"(?:https?://|mailto:|#)", target):
                continue
            path = target.partition("#")[0]
            resolved = posixpath.normpath(posixpath.join(str(PurePosixPath(document).parent), path))
            if resolved != "SHA256SUMS" and resolved not in entries:
                raise ValueError(f"Unresolved local documentation link in {document}; use an included artifact")
    for relative, data in entries.items():
        audit(relative, data, source=relative.startswith(("tools/", "source/", "patches/")))
    # Fail if another task changed input files while they were being captured.
    if git(source, "rev-parse", "HEAD").decode().strip() != head:
        raise ValueError("Source HEAD changed during packaging; retry after work is complete")
    for root, relative, before in snapshots:
        if read_allowed(root, relative) != before:
            raise ValueError(f"Input changed during packaging: {relative}")
    entries["SHA256SUMS"] = "".join(
        f"{sha256(data)}  {name}\n" for name, data in sorted(entries.items())
    ).encode("ascii")
    return entries, metadata


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    default_evidence = Path(__file__).resolve().parents[1]
    parser.add_argument("--evidence-root", type=Path, default=default_evidence)
    parser.add_argument("--source", type=Path, default=default_evidence.parent.parent / "plane-query-optimization")
    parser.add_argument("--base-commit", default=BASE_COMMIT)
    parser.add_argument("--production-commit", default=PRODUCTION_COMMIT)
    parser.add_argument("--expected-source-commit")
    parser.add_argument("--allow-uncommitted-source", action="store_true")
    parser.add_argument("--output", type=Path, help="New ZIP path; existing files are never overwritten")
    parser.add_argument("--check-only", action="store_true", help="Validate inputs and construct bundle in memory; write nothing")
    parser.add_argument("--verify", type=Path, metavar="ZIP", help="Verify an existing archive without extracting it")
    args = parser.parse_args()
    try:
        if args.verify:
            print(json.dumps(verify_archive(args.verify), indent=2))
            return 0
        entries, metadata = build(args)
        if args.check_only:
            print(json.dumps({"valid": True, "files": len(entries), "source_commit": metadata["source_snapshot_commit"]}, indent=2))
            return 0
        destination = args.output or args.evidence_root / f"plane-evidence-{metadata['source_snapshot_commit'][:12]}.zip"
        if destination.suffix.lower() != ".zip":
            raise ValueError("Output filename must end in .zip")
        with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, data in sorted(entries.items()):
                info = zipfile.ZipInfo(ARCHIVE_ROOT + "/" + name, date_time=(2026, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, data)
        print(json.dumps({"archive": destination.name, **verify_archive(destination)}, indent=2))
        return 0
    except (OSError, ValueError, UnicodeError, zipfile.BadZipFile, ET.ParseError) as error:
        # Do not echo input contents, paths, or environment values on failures.
        message = str(error) if isinstance(error, ValueError) else type(error).__name__
        print(f"Evidence bundle failed: {message}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
